MY CALENDAR WEB v1
Open index.html in a browser.
For iPhone home-screen installation, the web app must be hosted online; then open its URL in Safari and choose Share > Add to Home Screen.
